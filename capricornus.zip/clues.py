
class Clue(object):
    def __init__(self,
                 name,
                 contents):
        self.name = name
        self.contents = contents
